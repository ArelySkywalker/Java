+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
			       README
            Authors: Paolo Macias and Arely Miramontes

	    	     	       AshBot
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

1.  To run our program, double-click on the Ashbot.jar file to 
    execute.

2.  If the jar file does not run, be sure to check you have 
    the updated version of Java.

3.  Once the file runs, Start talking to our Ashbot and ask
    him questions about himself, and also about Pokemon!



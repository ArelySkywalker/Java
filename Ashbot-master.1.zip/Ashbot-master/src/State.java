
public enum State {
    alabama, alaska, arizona, arkansas, california, colorado, connecticut, delaware, florida, georgia,
	hawaii, idaho, illinois, nebraska, nevada, hampshire, jersey, mexico, york,
	carolina, dakota, ohio, oklahoma, oregon, pennsylvania, indiana, iowa, kansas, kentucky, 
	louisiana, maine, maryland, massachusetts, michigan, minnesota, mississippi, missouri, montana,
	rhodeisland, tennessee, texas, utah, vermont, virginia, washington, wisconsin, wyoming
	}

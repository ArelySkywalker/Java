/*
 * This just contains main which creates a new chat GUI.
 */


public class RunAsh
{

	public static void main(String[] args)
	{
		ChatGUI gui = new ChatGUI("Ashbot");

	}

}
